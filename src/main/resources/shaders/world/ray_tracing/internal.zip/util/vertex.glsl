#ifndef VERTEX_GLSL
#define VERTEX_GLSL

#include "common/shared.hpp"

const uint useColorLayerBit = 1u << 0u;
const uint useTextureBit = 1u << 1u;
const uint useOverlayBit = 1u << 2u;
const uint useGlintBit = 1u << 3u;
const uint forceNoPbrBit = 1u << 4u;
const uint windReactiveBit = 1u << 5u;
const uint alphaModeShift = 8u;
const uint coordinateShift = 12u;

layout(set = 1, binding = 6) readonly buffer PositionBufferAddr {
    uint64_t addrs[];
}
positionBufferAddrs;

layout(set = 1, binding = 7) readonly buffer MaterialBufferAddr {
    uint64_t addrs[];
}
materialBufferAddrs;

layout(std430, buffer_reference, buffer_reference_align = 8) readonly buffer PositionBuffer {
    PositionVertex vertices[];
}
positionBuffer;

layout(std430, buffer_reference, buffer_reference_align = 8) readonly buffer MaterialBuffer {
    MaterialVertex vertices[];
}
materialBuffer;

uint getGeometryBufferIndex(uint instanceID, uint geometryID) {
    return blasOffsets.offsets[instanceID] + geometryID;
}

bool hasColorLayer(uint packedData) {
    return (packedData & useColorLayerBit) != 0u;
}

bool hasTexture(uint packedData) {
    return (packedData & useTextureBit) != 0u;
}

bool hasOverlay(uint packedData) {
    return (packedData & useOverlayBit) != 0u;
}

bool hasGlint(uint packedData) {
    return (packedData & useGlintBit) != 0u;
}

bool forceNoPbr(uint packedData) {
    return (packedData & forceNoPbrBit) != 0u;
}

bool windReactive(uint packedData) {
    return (packedData & windReactiveBit) != 0u;
}

uint getAlphaMode(uint packedData) {
    return (packedData >> alphaModeShift) & 0xFu;
}

uint getCoordinate(uint packedData) {
    return (packedData >> coordinateShift) & 0xFu;
}

void loadTriangleIndices(uint geometryBufferIndex, uint primitiveID, out uint i0, out uint i1, out uint i2) {
    IndexBuffer indexBuffer = IndexBuffer(indexBufferAddrs.addrs[geometryBufferIndex]);
    uint indexBaseID = 3u * primitiveID;
    i0 = indexBuffer.indices[indexBaseID];
    i1 = indexBuffer.indices[indexBaseID + 1u];
    i2 = indexBuffer.indices[indexBaseID + 2u];
}

void loadTrianglePositions(uint geometryBufferIndex,
                           uint i0,
                           uint i1,
                           uint i2,
                           out PositionVertex p0,
                           out PositionVertex p1,
                           out PositionVertex p2) {
    PositionBuffer positionBufferRef = PositionBuffer(positionBufferAddrs.addrs[geometryBufferIndex]);
    p0 = positionBufferRef.vertices[i0];
    p1 = positionBufferRef.vertices[i1];
    p2 = positionBufferRef.vertices[i2];
}

void loadTriangleMaterial(uint geometryBufferIndex,
                          uint i0,
                          uint i1,
                          uint i2,
                          out MaterialVertex m0,
                          out MaterialVertex m1,
                          out MaterialVertex m2) {
    MaterialBuffer materialBufferRef = MaterialBuffer(materialBufferAddrs.addrs[geometryBufferIndex]);
    m0 = materialBufferRef.vertices[i0];
    m1 = materialBufferRef.vertices[i1];
    m2 = materialBufferRef.vertices[i2];
}

void loadTriangle(uint geometryBufferIndex,
                  uint primitiveID,
                  out uint i0,
                  out uint i1,
                  out uint i2,
                  out PositionVertex p0,
                  out PositionVertex p1,
                  out PositionVertex p2,
                  out MaterialVertex m0,
                  out MaterialVertex m1,
                  out MaterialVertex m2) {
    loadTriangleIndices(geometryBufferIndex, primitiveID, i0, i1, i2);
    loadTrianglePositions(geometryBufferIndex, i0, i1, i2, p0, p1, p2);
    loadTriangleMaterial(geometryBufferIndex, i0, i1, i2, m0, m1, m2);
}

#endif
