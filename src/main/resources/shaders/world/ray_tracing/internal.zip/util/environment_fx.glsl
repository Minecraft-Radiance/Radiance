#ifndef ENVIRONMENT_FX_GLSL
#define ENVIRONMENT_FX_GLSL

const float WATER_SURFACE_SENTINEL_MIN = 31.0;
const float WATER_SURFACE_SENTINEL_MAX = 31.5;

const float WATER_MODE_NATIVE_LIKE = 0.0;
const float WATER_MODE_SPARKLING = 1.0;

const float CLOUD_MODE_NATIVE = 0.0;
const float CLOUD_MODE_EFFICIENT = 1.0;
const float CLOUD_MODE_REALISTIC = 2.0;

float environmentHash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

float environmentValueNoise(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);

    float n000 = environmentHash13(i + vec3(0.0, 0.0, 0.0));
    float n100 = environmentHash13(i + vec3(1.0, 0.0, 0.0));
    float n010 = environmentHash13(i + vec3(0.0, 1.0, 0.0));
    float n110 = environmentHash13(i + vec3(1.0, 1.0, 0.0));
    float n001 = environmentHash13(i + vec3(0.0, 0.0, 1.0));
    float n101 = environmentHash13(i + vec3(1.0, 0.0, 1.0));
    float n011 = environmentHash13(i + vec3(0.0, 1.0, 1.0));
    float n111 = environmentHash13(i + vec3(1.0, 1.0, 1.0));

    float nx00 = mix(n000, n100, u.x);
    float nx10 = mix(n010, n110, u.x);
    float nx01 = mix(n001, n101, u.x);
    float nx11 = mix(n011, n111, u.x);
    float nxy0 = mix(nx00, nx10, u.y);
    float nxy1 = mix(nx01, nx11, u.y);
    return mix(nxy0, nxy1, u.z);
}

float environmentFbm(vec3 p, int octaves) {
    float sum = 0.0;
    float amplitude = 0.5;
    vec3 q = p;
    for (int i = 0; i < 6; i++) {
        if (i >= octaves) {
            break;
        }
        sum += amplitude * environmentValueNoise(q);
        q = q * 2.03 + vec3(13.1, 7.7, 11.3);
        amplitude *= 0.5;
    }
    return sum;
}

vec2 environmentWaveGradient(vec2 uv,
                             float time,
                             vec2 direction,
                             float frequency,
                             float speed,
                             float amplitude) {
    vec2 dir = normalize(direction);
    float phase = dot(uv, dir) * frequency + time * speed;
    return dir * (cos(phase) * frequency * amplitude);
}

vec2 rainRippleLayer(vec2 worldXZ,
                     float gameTime,
                     float cellScale,
                     float phaseOffset,
                     float speed,
                     float strength) {
    vec2 rippleUv = worldXZ * cellScale;
    vec2 cell = floor(rippleUv);
    vec2 local = fract(rippleUv) - 0.5;

    float hashA = environmentHash13(vec3(cell + phaseOffset, 19.7 + phaseOffset));
    float hashB = environmentHash13(vec3(cell.yx + 13.0 + phaseOffset, 31.3 + phaseOffset));
    vec2 dropCenter = (vec2(hashA, hashB) - 0.5) * 0.76;
    vec2 toDrop = local - dropCenter;

    float dist = max(length(toDrop), 1e-4);
    float phase = fract(environmentHash13(vec3(cell + phaseOffset + 5.0, 43.1 + phaseOffset)) + gameTime * speed);
    float ringCenter = mix(0.06, 0.84, phase);
    float ringBand = 1.0 - smoothstep(0.018, 0.115, abs(dist - ringCenter));
    float wave = sin((dist - ringCenter) * mix(22.0, 30.0, strength));
    float fade = (1.0 - phase) * (0.45 + 0.55 * hashA);
    return toDrop / dist * wave * ringBand * fade * strength;
}

float rainSurfaceCoverage(vec3 geoNormal, vec3 worldPos, float rainGradient) {
    float rain = smoothstep(0.12, 0.95, rainGradient);
    if (rain <= 0.0) {
        return 0.0;
    }

    vec3 n = normalize(geoNormal);
    float facingUp = smoothstep(0.08, 0.95, n.y);
    vec3 puddleCell = floor(vec3(worldPos.x * 0.125, worldPos.y * 0.04, worldPos.z * 0.125));
    float puddleMask = smoothstep(0.62, 0.88, environmentHash13(puddleCell));
    float wetFilm = mix(0.24, 1.0, puddleMask);

    return clamp(rain * facingUp * wetFilm, 0.0, 1.0);
}

vec2 rainRippleOffset(vec2 worldXZ, float gameTime, float rainGradient) {
    float rain = smoothstep(0.08, 1.0, rainGradient);
    if (rain <= 0.0) {
        return vec2(0.0);
    }

    vec2 ripple = rainRippleLayer(worldXZ, gameTime * mix(0.92, 1.18, rain), 0.82, 0.0, mix(0.95, 1.2, rain), 1.0);
    ripple += rainRippleLayer(worldXZ * 1.6 + vec2(7.3, -4.7), gameTime * mix(1.18, 1.45, rain), 1.24, 9.7,
        mix(1.15, 1.55, rain), 0.62);
    return ripple * rain * 1.15;
}

vec3 applyRainRippleNormal(vec3 baseNormal,
                           vec3 geoNormal,
                           vec3 worldPos,
                           float gameTime,
                           float rainGradient,
                           float strength) {
    vec3 resolvedGeoNormal = normalize(geoNormal);
    vec3 resolvedBaseNormal = normalize(baseNormal);
    if (abs(resolvedGeoNormal.y) < 0.35 || strength <= 0.0) {
        return resolvedBaseNormal;
    }

    vec2 ripple = rainRippleOffset(worldPos.xz, gameTime, rainGradient);
    if (any(isnan(ripple))) {
        ripple = vec2(0.0);
    }
    vec3 tangentX = normalize(vec3(1.0, 0.0, 0.0) - resolvedGeoNormal * resolvedGeoNormal.x);
    if (dot(tangentX, tangentX) <= 1e-6) {
        tangentX = normalize(cross(vec3(0.0, 0.0, 1.0), resolvedGeoNormal));
    }
    vec3 tangentZ = normalize(cross(resolvedGeoNormal, tangentX));

    vec3 rippleNormal =
        normalize(resolvedGeoNormal + tangentX * ripple.x * strength + tangentZ * ripple.y * strength);
    if (any(isnan(rippleNormal))) {
        return resolvedBaseNormal;
    }
    float rippleBlend = clamp(rainGradient * 0.45 + strength * 2.75, 0.0, 1.0);
    return normalize(mix(resolvedBaseNormal, rippleNormal, rippleBlend));
}

vec3 windReactiveDisplacement(vec3 localPos,
                              vec3 worldPos,
                              float gameTime,
                              float bendMask,
                              float intensity) {
    float bend = smoothstep(0.08, 0.95, bendMask);
    if (bend <= 0.0 || intensity <= 0.0) {
        return vec3(0.0);
    }

    float gust =
        sin(gameTime * 0.9 + worldPos.x * 0.11 + worldPos.z * 0.08)
            + 0.5 * sin(gameTime * 1.7 + worldPos.x * 0.05 - worldPos.z * 0.09);
    float flutter = sin(gameTime * 2.2 + localPos.y * 1.3 + worldPos.x * 0.19) * 0.35;
    vec2 swayDir = normalize(vec2(0.78, 0.43) + vec2(flutter, gust * 0.2));
    float amplitude = intensity * bend * (0.65 + 0.35 * clamp(abs(gust), 0.0, 1.0));

    return vec3(swayDir.x, 0.0, swayDir.y) * amplitude;
}

vec3 cyberpunkRainSkyRadiance(vec3 sunnyRadiance, vec3 rayDir, vec3 sunDir, float rainGradient) {
    float rain = smoothstep(0.1, 1.0, rainGradient);
    if (rain <= 0.0) {
        return sunnyRadiance;
    }

    vec3 resolvedRayDir = normalize(rayDir);
    vec3 resolvedSunDir = normalize(sunDir);
    float nightFactor = 1.0 - smoothstep(-0.02, 0.38, resolvedSunDir.y);
    float horizonFactor = pow(1.0 - clamp(abs(resolvedRayDir.y), 0.0, 1.0), 2.4);
    float zenithFactor = pow(clamp(resolvedRayDir.y * 0.5 + 0.5, 0.0, 1.0), 1.8);

    float peak = max(sunnyRadiance.r, max(sunnyRadiance.g, sunnyRadiance.b));
    float brightCarry = smoothstep(0.4, 2.5, peak);

    vec3 coolBase = mix(vec3(0.02, 0.03, 0.05), vec3(0.03, 0.10, 0.16), nightFactor);
    vec3 tealLift = vec3(0.01, 0.08, 0.14) * zenithFactor * (0.35 + 0.65 * nightFactor);
    vec3 magentaGlow = vec3(0.08, 0.02, 0.08) * horizonFactor * (0.35 + 0.65 * nightFactor);
    vec3 rainyRadiance = coolBase + tealLift + magentaGlow;
    rainyRadiance += sunnyRadiance * mix(0.12, 0.32, brightCarry);

    return mix(sunnyRadiance, rainyRadiance, rain);
}

vec3 cyberpunkRainKeyLight(vec3 lightRadiance, float rainGradient) {
    float rain = smoothstep(0.1, 1.0, rainGradient);
    vec3 rainyLight = lightRadiance * vec3(0.34, 0.40, 0.52);
    return mix(lightRadiance, rainyLight, rain);
}

bool decodeWaterSurfaceSentinel(inout float encodedEmission) {
    if (encodedEmission >= WATER_SURFACE_SENTINEL_MIN
        && encodedEmission <= WATER_SURFACE_SENTINEL_MAX) {
        encodedEmission = 0.0;
        return true;
    }
    return false;
}

vec3 applyWaterSurfaceNormal(vec3 baseNormal,
                             vec3 geoNormal,
                             vec3 worldPos,
                             float gameTime,
                             float waterMode,
                             float rainGradient) {
    vec3 resolvedGeoNormal = normalize(geoNormal);
    vec3 resolvedBaseNormal = normalize(baseNormal);
    if (abs(resolvedGeoNormal.y) < 0.35) {
        return resolvedBaseNormal;
    }

    float sparkleMix = step(0.5, waterMode);
    float time = gameTime * mix(0.55, 1.05, sparkleMix);
    vec2 p = worldPos.xz * mix(0.11, 0.16, sparkleMix);

    vec2 wave = vec2(0.0);
    wave += environmentWaveGradient(p, time, vec2(0.94, 0.34), mix(1.35, 1.9, sparkleMix),
        mix(0.82, 1.18, sparkleMix), mix(0.26, 0.34, sparkleMix));
    wave += environmentWaveGradient(p * 1.75 + vec2(1.7, -2.1), time * 1.16, vec2(-0.39, 0.92),
        mix(2.1, 2.9, sparkleMix), mix(1.0, 1.42, sparkleMix), mix(0.11, 0.18, sparkleMix));
    wave += environmentWaveGradient(p * 2.85 - vec2(0.8, 1.4), time * 1.43, vec2(0.61, -0.79),
        mix(3.4, 4.4, sparkleMix), mix(1.28, 1.82, sparkleMix), mix(0.05, 0.10, sparkleMix));
    wave += vec2(
        sin((p.x + p.y * 0.72) * mix(2.0, 2.8, sparkleMix) - time * mix(0.9, 1.3, sparkleMix)),
        cos((p.x * 0.78 - p.y) * mix(1.8, 2.6, sparkleMix) + time * mix(1.0, 1.48, sparkleMix)))
        * mix(0.045, 0.095, sparkleMix);

    vec2 rainRipple = rainRippleOffset(worldPos.xz * mix(1.1, 1.45, sparkleMix),
        gameTime * mix(1.0, 1.2, sparkleMix), rainGradient);
    if (any(isnan(rainRipple))) {
        rainRipple = vec2(0.0);
    }
    wave += rainRipple * mix(0.28, 0.44, sparkleMix);

    vec3 tangentX = normalize(vec3(1.0, 0.0, 0.0) - resolvedGeoNormal * resolvedGeoNormal.x);
    if (dot(tangentX, tangentX) <= 1e-6) {
        tangentX = normalize(cross(vec3(0.0, 0.0, 1.0), resolvedGeoNormal));
    }
    vec3 tangentZ = normalize(cross(resolvedGeoNormal, tangentX));

    float amplitude = mix(0.11, 0.26, sparkleMix);
    vec3 proceduralNormal =
        normalize(resolvedGeoNormal + tangentX * wave.x * amplitude + tangentZ * wave.y * amplitude);
    if (any(isnan(proceduralNormal))) {
        return resolvedBaseNormal;
    }
    return normalize(mix(resolvedBaseNormal, proceduralNormal, mix(0.56, 0.88, sparkleMix)));
}

float cloudVerticalProfile(float localY) {
    float h = clamp(localY / 4.0, 0.0, 1.0);
    return smoothstep(0.04, 0.24, h) * (1.0 - smoothstep(0.62, 0.98, h));
}

float sampleCloudDensity(vec3 sampleWorldPos, float localY, float gameTime, float cloudMode) {
    float realism = clamp((cloudMode - CLOUD_MODE_EFFICIENT)
        / max(CLOUD_MODE_REALISTIC - CLOUD_MODE_EFFICIENT, 1.0), 0.0, 1.0);
    float vertical = cloudVerticalProfile(localY);
    if (vertical <= 0.0) {
        return 0.0;
    }

    float drift = gameTime * mix(0.015, 0.026, realism);
    vec3 coarseCoord = vec3(sampleWorldPos.x * 0.028 + drift, localY * 0.24,
        sampleWorldPos.z * 0.028 - drift * 0.7);
    vec3 detailCoord = vec3(sampleWorldPos.x * 0.09 - drift * 1.8, localY * 0.55 + drift * 0.5,
        sampleWorldPos.z * 0.09 + drift);

    float coarse = environmentFbm(coarseCoord, realism > 0.5 ? 5 : 3);
    float detail = environmentFbm(detailCoord, realism > 0.5 ? 4 : 2);
    float wisps = environmentValueNoise(detailCoord * 1.7 + vec3(4.2, 1.9, 7.3));

    float densityField = coarse * mix(0.92, 0.82, realism)
        + detail * mix(0.22, 0.36, realism)
        + wisps * mix(0.06, 0.14, realism);
    float threshold = mix(0.54, 0.46, realism);
    return smoothstep(threshold, 0.95, densityField) * vertical;
}

#endif
